#include <windows.h>  						// for MS Windows
#include <iostream>
#include <GL/glut.h>  						// GLUT, include glu.h and gl.h
#include <cmath>

using namespace std;

int ww = 600, wh = 400;
int xi, yi, xf, yf;
double eccentricity = 0.6;

void initGL() {
	glClearColor(0.0, 0.0, 0.0, 1.0); 		// Set background (clear) color to black
	glViewport(0, 0, ww, wh);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, (GLdouble)ww, 0.0, (GLdouble)wh);
	glMatrixMode(GL_MODELVIEW);
}

void drawPoint(GLint x, GLint y)
{
	//glClear(GL_COLOR_BUFFER_BIT);	
	glColor3f(0.0, 1.0, 0.0);

	glPointSize(1);

	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
	glFlush();
}

int xTranslate(int x, int x1) {
	return x + x1;
}

int yTranslate(int y, int y1) {
	return y + y1;
}

void drawEllipse(GLint x1, GLint y1, GLint x2, GLint y2) {

	double a1 = sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
	int a = round(a1);
	int b = round(a * eccentricity);

	int a2 = pow(a, 2);
	int b2 = pow(b, 2);
	
	int p = b2 + a2 * (0.25 - b);

	int x = 0;
	int y = b;

	int fx = 2 * pow(b, 2) * x;
	int fy = 2 * pow(a, 2) * y;
	

	do  {
		
		drawPoint(xTranslate(x, x1), yTranslate(y, y1));
		drawPoint(xTranslate(-x, x1), yTranslate(-y, y1));
		drawPoint(xTranslate(x, x1), yTranslate(-y, y1));
		drawPoint(xTranslate(-x, x1), yTranslate(y, y1
		
		if (p < 0) {
			p += b2 * (2 * x + 3);
			
		}
		else {
			p += b2 * (2 * x + 3) + 2 * a2 * (1 -  y);
			y--;
			fy -= 2 * a2;
		}
		x++;
		fx += 2 * b2;

	} while (fx < fy);

	p = b2 * pow(x + 0.5, 2) + a2 * pow(y - 1, 2) - a2 * b2;

	while (y >= 0) {
		
		drawPoint(xTranslate(x, x1), yTranslate(y, y1));
		drawPoint(xTranslate(-x, x1), yTranslate(-y, y1));
		drawPoint(xTranslate(x, x1), yTranslate(-y, y1));
		drawPoint(xTranslate(-x, x1), yTranslate(y, y1));
		
		if (p < 0) {
			p += a2 * (3 - 2 * y) + 2 * b2 * (1 + x);
			x++;
			fx += 2 * b2;
		}
		else {
			p += a2 * (3 - 2 * y);
		}
		y--;
		fy -= 2 * a2;
	}
}


void mouse(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON) {
		if (state == GLUT_DOWN) {
			xi = x;
			yi = (wh - y);
		}
		if (state == GLUT_UP) {
			xf = x;
			yf = (wh - y);
			drawEllipse(xi, yi, xf, yf);
		}

	}

}

void keyboard(unsigned char key, int x, int y) {
	switch (key) {	
	case 81: exit(0);					    // exit			
			 break;
	case 69: glClear(GL_COLOR_BUFFER_BIT);
			 glFlush();		
	}

}


/* Callback handler for window re-paint event */
void display() {
	// Swap front and back buffers (of double buffered mode)   
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);            // Initialize GLUT
	//glutInitDisplayMode(GLUT_DOUBLE); // Enable double buffered mode
	glutInitWindowSize(ww, wh);  // Initial window width and height
	glutInitWindowPosition(200, 200); // Initial window top-left corner (x, y)
	glutCreateWindow("ellipse b=0.6a");      // Create window with given title
	glutDisplayFunc(display);     // Register callback handler for window re-paint
	//glutReshapeFunc(reshape);      //Register callback handler for window re-shape
	//glutTimerFunc(0, Timer, 0);   // First timer call immediately
	//glutSpecialFunc(specialKeys); // Register callback handler for special-key event
	glutKeyboardFunc(keyboard);   // Register callback handler for special-key event
	//glutFullScreen();             // Put into full screen
	glutMouseFunc(mouse);   // Register callback handler for mouse event
	initGL();                     // Our own OpenGL initialization
	glutMainLoop();               // Enter event-processing loop
	return 0;
}