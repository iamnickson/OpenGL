#include <windows.h>  // for MS Windows
#include <iostream>
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <cmath>

using namespace std;

int ww = 600, wh = 400;
int xi, yi, xf, yf;

void initGL() {
	glClearColor(0.0, 0.0, 0.0, 1.0); // Set background (clear) color to black
	glViewport(0, 0, ww, wh);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, (GLdouble)ww, 0.0, (GLdouble)wh);
	glMatrixMode(GL_MODELVIEW);
}

void drawPoint(GLint x, GLint y)
{
	//glClear(GL_COLOR_BUFFER_BIT);	
	glColor3f(0.0, 1.0, 0.0);

	glPointSize(1);

	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
	glFlush();
}

int xTranslate(int x, int x1) {
	return x + x1;
}

int yTranslate(int y, int y1) {
	return y + y1;
}

void drawCircle(GLint x1, GLint y1, GLint x2, GLint y2) {

	double r1 = sqrt(pow(x2 - x1, 2) + pow(y2-y1, 2));
	int r = round(r1);
	
	int x = 0;
	int y = r;

	int d = 3 - 2 * r;

	while (x <= y) {
		drawPoint(xTranslate(x, x1), yTranslate(y, y1));
		drawPoint(xTranslate(y, x1), yTranslate(x, y1));
		//drawPoint(y, x);
		drawPoint(xTranslate(y, x1), yTranslate(-x, y1));
		drawPoint(xTranslate(x, x1), yTranslate(-y, y1));

		drawPoint(xTranslate(-x, x1), yTranslate(y, y1));
		drawPoint(xTranslate(-y, x1), yTranslate(x, y1));
		
		drawPoint(xTranslate(-y, x1), yTranslate(-x, y1));
		drawPoint(xTranslate(-x, x1), yTranslate(-y, y1));

		//drawPoint(y, -x);
		//drawPoint(x, -y);

		//drawPoint(-x, y);
		//drawPoint(-y, x);

		//drawPoint(-y, -x);
		//drawPoint(-x, -y);

		if (d < 0) {
			d = d + 4 * x + 6;
		}
		else {
			d = d + 4 * (x - y) + 10;
			y--;
		}
		x++;
	}

}


void mouse(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON) {
		if (state == GLUT_DOWN) {
			xi = x;
			yi = (wh - y);
		}
		if (state == GLUT_UP) {
			xf = x;
			yf = (wh - y);
			drawCircle(xi, yi, xf, yf);
		}

	}

}


/* Callback handler for window re-paint event */
void display() {
	// Swap front and back buffers (of double buffered mode)   
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);            // Initialize GLUT
	//glutInitDisplayMode(GLUT_DOUBLE); // Enable double buffered mode
	glutInitWindowSize(ww, wh);  // Initial window width and height
	glutInitWindowPosition(200, 200); // Initial window top-left corner (x, y)
	glutCreateWindow("draw polygons");      // Create window with given title
	glutDisplayFunc(display);     // Register callback handler for window re-paint
	//glutReshapeFunc(reshape);      //Register callback handler for window re-shape
	//glutTimerFunc(0, Timer, 0);   // First timer call immediately
	//glutSpecialFunc(specialKeys); // Register callback handler for special-key event
	//glutKeyboardFunc(keyboard);   // Register callback handler for special-key event
	//glutFullScreen();             // Put into full screen
	glutMouseFunc(mouse);   // Register callback handler for mouse event
	initGL();                     // Our own OpenGL initialization
	glutMainLoop();               // Enter event-processing loop
	return 0;
}