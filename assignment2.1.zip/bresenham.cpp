#include <windows.h>  // for MS Windows
#include <iostream>
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <cmath>

using namespace std;

int ww = 600, wh = 400;
int xi, yi, xf, yf, initX, initY;
//bool firstLine = true;

void initGL() {
	glClearColor(0.0, 0.0, 0.0, 1.0); // Set background (clear) color to black
	glViewport(0, 0, ww, wh);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, (GLdouble)ww, 0.0, (GLdouble)wh);
	glMatrixMode(GL_MODELVIEW);
}

void drawpoint(GLint x, GLint y)
{
	//glClear(GL_COLOR_BUFFER_BIT);	
	glColor3f(0.0, 1.0, 0.0);

	glPointSize(1);

	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
	glFlush();
}

void rangeOne(GLint x1, GLint y1, GLint x2, GLint y2) {

	int dx = x2 - x1;
	int dy = y2 - y1;	

	int x = x1;
	int y = y1;

	int dt = 2 * (dy - dx);
	int ds = 2 * dy;

	int d = 2*dy - dx;

	//cout << "x=" << x << " y=" << y << "\n";
	//cout << "dt=" << dt << " ds=" << ds << " d=" << d << "\n";

	drawpoint(x, y);

	while(x < x2) {
		x++;
		if (d < 0) {
			d = d + ds;
		}
		else {
			y++;
			d = d + dt;
		}
		//cout << "x=" << x << " y=" << y << " d=" << d << "\n";
		drawpoint(x, y);
	}
}

void rangeEight(GLint x1, GLint y1, GLint x2, GLint y2) {

	int dx = x2 - x1;
	int dy = y2 - y1;

	int x = x1;
	int y = y1;

	int dt = 2 * (dy - dx);
	int ds = 2 * dy;

	int d = 2 * dy - dx;

	//cout << "x=" << x << " y=" << y << "\n";
	//cout << "dt=" << dt << " ds=" << ds << " d=" << d << "\n";

	drawpoint(x, 2*y2 -y);

	while (x < x2) {
		x++;
		if (d < 0) {
			d = d + ds;
		}
		else {
			y++;
			d = d + dt;
		}
		//cout << "x=" << x << " y=" << y << " d=" << d << "\n";
		
		drawpoint(x, 2*y2 - y);
	}
}

void rangeTwo(GLint x1, GLint y1, GLint x2, GLint y2) {

	int dx = x2 - x1;
	int dy = y2 - y1;

	int x = x1;
	int y = y1;

	int dt = 2 * (dy - dx);
	int ds = 2 * dy;

	int d = 2 * dy - dx;

	//cout << "x=" << x << " y=" << y << "\n";
	//cout << "dt=" << dt << " ds=" << ds << " d=" << d << "\n";

	drawpoint(y, x);

	while (x < x2) {
		x++;
		if (d < 0) {
			d = d + ds;
		}
		else {
			y++;
			d = d + dt;
		}
		//cout << "x=" << x << " y=" << y << " d=" << d << "\n";

		drawpoint(y, x);
	}
}

void rangeSeven(GLint x1, GLint y1, GLint x2, GLint y2) {

	int dx = x2 - x1;
	int dy = y2 - y1;

	int x = x1;
	int y = y1;

	int dt = 2 * (dy - dx);
	int ds = 2 * dy;

	int d = 2 * dy - dx;

	//cout << "x=" << x << " y=" << y << "\n";
	//cout << "dt=" << dt << " ds=" << ds << " d=" << d << "\n";

	drawpoint(2*y1-y, x);

	while (x < x2) {
		x++;
		if (d < 0) {
			d = d + ds;
		}
		else {
			y++;
			d = d + dt;
		}
		//cout << "x=" << x << " y=" << y << " d=" << d << "\n";

		drawpoint(2*y1-y, x);
	}
}

void drawLine(int x1, int y1, int x2, int y2) {

	int dx = x2 - x1;
	int dy = y2 - y1;
	int absdx = abs(dx);
	int absdy = abs(dy);

	if (absdy < absdx && dy > 0 && dx > 0) {
		//cout << "rangeOne!" << "\n";
		rangeOne(x1, y1, x2, y2);
	}
	else if (absdy < absdx && dy < 0 && dx > 0) {
		//cout << "rangeEight!" << "\n";
		y1 = 2 * y2 - y1;
		rangeEight(x1, y1, x2, y2);
	}
	else if (absdy > absdx && dy > 0 && dx > 0) {
		//cout << "rangeTwo!" << "\n";
		rangeTwo(y1, x1, y2, x2);
	}
	else if (absdy > absdx && dy < 0 && dx > 0) {
		//cout << "rangeSeven!" << "\n";
		x1 = 2 * x2 - x1;
		rangeSeven(y2, x2, y1, x1);
	}
	else if (absdy < absdx && dy > 0 && dx < 0) {
		//cout << "rangeFour!" << "\n";
		y2 = 2 * y1 - y2;
		rangeEight(x2, y2, x1, y1);
	}
	else if (absdy > absdx && dy > 0 && dx < 0) {
		//cout << "rangeThree!" << "\n";
		x2 = 2 * x1 - x2;
		rangeSeven(y1, x1, y2, x2);
	}
	else if (absdy < absdx && dy < 0 && dx < 0) {
		//cout << "rangeFive!" << "\n";		
		rangeOne(x2, y2, x1, y1);
	}
	else if (absdy > absdx && dy < 0 && dx < 0) {
		//cout << "rangeSix!" << "\n";
		rangeTwo(y2, x2, y1, x1);
	}
	
}


void mouse(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON) {
		if (state == GLUT_DOWN) {
			xi = x;
			yi = (wh - y);
		}
		if (state == GLUT_UP) {
			xf = x;
			yf = (wh - y);
			drawLine(xi, yi, xf, yf);
		}

	}

}


/* Callback handler for window re-paint event */
void display() {
	
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);            // Initialize GLUT
	//glutInitDisplayMode(GLUT_DOUBLE); // Enable double buffered mode
	glutInitWindowSize(ww, wh);  // Initial window width and height
	glutInitWindowPosition(200, 200); // Initial window top-left corner (x, y)
	glutCreateWindow("draw polygons");      // Create window with given title
	glutDisplayFunc(display);     // Register callback handler for window re-paint
	//glutReshapeFunc(reshape);      //Register callback handler for window re-shape
	//glutTimerFunc(0, Timer, 0);   // First timer call immediately
	//glutSpecialFunc(specialKeys); // Register callback handler for special-key event
	//glutKeyboardFunc(keyboard);   // Register callback handler for special-key event
	//glutFullScreen();             // Put into full screen
	glutMouseFunc(mouse);   // Register callback handler for mouse event
	initGL();                     // Our own OpenGL initialization
	glutMainLoop();               // Enter event-processing loop
	return 0;
}