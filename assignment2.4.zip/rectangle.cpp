#include <windows.h>  
#include <GL/glut.h> 

int ww = 600, wh = 400;
int xi, yi, xf, yf, initX, initY;
bool firstLine = true;

void initGL() {
	glClearColor(0.0, 0.0, 0.0, 1.0); 
	glViewport(0, 0, ww, wh);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, (GLdouble)ww, 0.0, (GLdouble)wh);
	glMatrixMode(GL_MODELVIEW);
}

void drawline()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glLineWidth(2);

	glBegin(GL_LINES);
	glColor3f(1.0f, 0.0f, 0.0f);
	for (int i = 0; i < 100; i++) {
		glVertex2i(100, 100 + 2 * i);
		glVertex2i(400, 100 + 2 * i);
	}
	glEnd();
	glFlush();
}



void display() {
	drawline();	
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);            // Initialize GLUT	
	glutInitWindowSize(ww, wh);  // Initial window width and height
	glutInitWindowPosition(200, 200); // Initial window top-left corner (x, y)
	glutCreateWindow("draw dots");      // Create window with given title
	glutDisplayFunc(display);     // Register callback handler for window re-paint	
	initGL();                     // Our own OpenGL initialization
	glutMainLoop();               // Enter event-processing loop
	return 0;
}