#include <windows.h>  
#include <GL/glut.h> 
#include <cmath>


int ww = 600, wh = 500;
int xi, yi, xf, yf, initX, initY;
bool firstLine = true;

void initGL() {
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glViewport(0, 0, ww, wh);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, (GLdouble)ww, 0.0, (GLdouble)wh);
	glMatrixMode(GL_MODELVIEW);
}

void drawline1(GLint x1, GLint y1)
{
	//glClear(GL_COLOR_BUFFER_BIT);
	glLineWidth(1);

	glBegin(GL_LINES);
	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2i(x1, y1);
	glVertex2i(300, y1);
	glEnd();
	glFlush();
}

void drawTriangle1(GLint x1, GLint y1, GLint x2, GLint y2) {

	float xincrement = 0.0;
	float yincrement = 0.0;

	float dx = x2 - x1;
	float dy = y2 - y1;

	float x = x1;
	float y = y1;

	float steps;

	if (abs(dx) > abs(dy)) {
		steps = abs(dx);
	}
	else {
		steps = abs(dy);
	}

	if (steps > 0) {
		xincrement = dx / steps;
		yincrement = dy / steps;
	}

	drawline1(x, y);

	for (int i = 0; i < steps; i++) {

		x = x + xincrement;
		y = y + yincrement;

		drawline1(round(x), round(y));

	}
}

void drawline2(GLint x1, GLint y1)
{
	//glClear(GL_COLOR_BUFFER_BIT);
	glLineWidth(1);

	glBegin(GL_LINES);
	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2i(300, y1);
	glVertex2i(x1, y1);	
	glEnd();
	glFlush();
}

void drawTriangle2(GLint x1, GLint y1, GLint x2, GLint y2) {

	float xincrement = 0.0;
	float yincrement = 0.0;

	float dx = x2 - x1;
	float dy = y2 - y1;

	float x = x1;
	float y = y1;

	float steps;

	if (abs(dx) > abs(dy)) {
		steps = abs(dx);
	}
	else {
		steps = abs(dy);
	}

	if (steps > 0) {
		xincrement = dx / steps;
		yincrement = dy / steps;
	}

	drawline2(x, y);

	for (int i = 0; i < steps; i++) {

		x = x + xincrement;
		y = y + yincrement;

		drawline2(round(x), round(y));

	}
}



void display() {
	drawTriangle1(100, 100, 300, 400);
	drawTriangle2(450, 100, 300, 400);
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);            // Initialize GLUT	
	glutInitWindowSize(ww, wh);  // Initial window width and height
	glutInitWindowPosition(200, 200); // Initial window top-left corner (x, y)
	glutCreateWindow("draw dots");      // Create window with given title
	glutDisplayFunc(display);     // Register callback handler for window re-paint	
	initGL();                     // Our own OpenGL initialization
	glutMainLoop();               // Enter event-processing loop
	return 0;
}