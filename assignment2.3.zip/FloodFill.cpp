#include <windows.h>  						// for MS Windows
#include <iostream>
#include <GL/glut.h>  						// GLUT, include glu.h and gl.h
#include <cmath>

int ww = 600, wh = 500;
float bgCol[3] = { 1.0, 1.0, 1.0 };
float intCol[3] = { 0.0, 0.0, 1.0 };
float fillCol[3] = { 1.0, 0.0, 0.0 };

void setPixel(int pointx, int pointy, float f[3])
{
	//glClear(GL_COLOR_BUFFER_BIT);
	glPointSize(1.0);
	glBegin(GL_POINTS);
	glColor3fv(f);
	glVertex2i(pointx, pointy);
	glEnd();
	glFlush();
}

void getPixel(int x, int y, float pixels[3])
{
	glReadPixels(x, y, 1.0, 1.0, GL_RGB, GL_FLOAT, pixels);
}

//void changePixCol(int x, int y, float backgroundColor[3], float interiorColor[3])
//{
//	float pixels[3];
//	getPixel(x, y, pixels);
//	if (pixels[0] == interiorColor[0] && (pixels[1]) == interiorColor[1] && (pixels[2]) == interiorColor[2])
//		setPixel(x, y, backgroundColor);
//	else setPixel(x, y, interiorColor);
//}

void FloodFill(int x, int y, float fillColor[3], float borderColor[3])
{
	float pixels[3];
	getPixel(x, y, pixels);
	bool intEqBordC = (pixels[0] == intCol[0] && (pixels[1]) == intCol[1] && (pixels[2]) == intCol[2]);	
	if (intEqBordC) {
		setPixel(x, y, fillColor);
		FloodFill(x + 1, y, fillCol, bgCol);
		FloodFill(x - 1, y, fillCol, bgCol);
		FloodFill(x, y + 1, fillCol, bgCol);
		FloodFill(x, y - 1, fillCol, bgCol);

	}
}

void drawPolygon(int x1, int y1, int x2, int y2)
{
	glBegin(GL_POLYGON);
		glColor3fv(intCol);
		glVertex2i(x1, y1);
		glVertex2i(x2, y1);
		glVertex2i(x2, y2);
		glVertex2i(x1, y2);
	glEnd();
	glFlush();
}

void display()
{
	//glClearColor(1.0, 1.0, 1.0, 1.0);
	//glClear(GL_COLOR_BUFFER_BIT);
	//drawPolygon(150, 250, 200, 300);
	//glFlush();

}

void mouse(int btn, int state, int x, int y)
{
	if (btn == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		int xi = x;
		int yi = (wh - y);

		FloodFill(xi, yi, fillCol, bgCol);

		//swap interior color and fill color
		float tempCol[3] = { intCol[0],intCol[1],intCol[2] };

		intCol[0] = fillCol[0];
		intCol[1] = fillCol[1];
		intCol[2] = fillCol[2];

		fillCol[0] = tempCol[0];
		fillCol[1] = tempCol[1];
		fillCol[2] = tempCol[2];

	}
}

void myinit()
{
	glViewport(0, 0, ww, wh);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, (GLdouble)ww, 0.0, (GLdouble)wh);
	glMatrixMode(GL_MODELVIEW);

	glClearColor(1.0, 1.0, 1.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);
	drawPolygon(150, 250, 210, 310);
	//glFlush();
	//drawPolygon(150, 250, 200, 300);
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(ww, wh);   // Set the window's initial width & height
	glutInitWindowPosition(200, 200); // Position the window's initial top-left corner
	glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
	glutDisplayFunc(display);
	myinit();
	glutMouseFunc(mouse);
	glutMainLoop();

	return 0;
}
